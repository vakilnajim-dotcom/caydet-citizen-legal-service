CAYDET CITIZEN LEGAL SERVICE — website starter

Files:
- index.html: complete responsive one-page website with WhatsApp buttons.

WhatsApp:
- Configured for India number +91 98400 32803.
- To change the number, replace 919840032803 in the WhatsApp URLs.

Free hosting (GitHub Pages):
1. Sign in or create an account at https://github.com/
2. Create a new public repository, for example: caydet-citizen-legal-service
3. Upload index.html to the repository root and commit.
4. Open repository Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. The public URL will appear in Settings → Pages.

This package creates the website files but does not itself publish/host the site.
